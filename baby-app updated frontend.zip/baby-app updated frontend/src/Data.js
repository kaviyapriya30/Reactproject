const Data=[
    {
    id:1,
    title:"Short Sleeves Jumpsuit ",
    price:"820.00",
    desc:" Ikeda Designs Printed Short Sleeves Jumpsuit With Ruffles - Pink 4 to 5 Years, The outfit that'll provide utmost comfort to your baby.",
    img :"/assets/images/products/img1.png"
    },
    {
    id:2,
    title:"Carter's Reindeer Jersey Tee - Green ",
    price:"755.00",
    desc:"Carter's is the leading brand of children's clothing, 5 to 6 Years, (Carter's size:5-6T), Comfy round neck tee for boys ",
    img :"/assets/images/products/img2.png"
    },
    {
    id:3,
    title:"Kookie Kids Full Sleeves Frock with Bow",
    price:"607.00",
    desc:"Kookie Kids aims at offering exclusivity at its best with its extensive range of quality products that showcase a blend of International taste and comfort for children.12 to 18 Months, (Size 90), Trendy round neck frock for girls",
    img :"/assets/images/products/img3.png"
    },
    {
    id:4,
    title:"Babyoye Full Sleeves Frock Floral Patch ",
    price:"780.00",
    desc:" Babyoye 'super-cute must haves' are designed to capture the magic of childhood, making perfect memories for the cute little adventurers. 12 to 18 Months, snug round neck frock with back button closure for girls",
    img :"/assets/images/products/img4.png"
    },
    {
    id:5,
    title:"Babyhug Full Sleeves Hooded Jacket ",
    price:"649.00",
    desc:"Babyhug is India's largest and most trusted baby care brand. When it comes to the needs of their little ones, countless mums can vouch for the convenience, safety, and quality that is synonymous with Babyhug. ",
    img :"/assets/images/products/img5.png"
    },
    {
    id:6,
    title:"Carter's 2-Piece Dinosaur Button-Front Shirt & Pant Set",
    price:"805.00",
    desc:"Carter's is the leading brand of children's clothing, gifts and accessories in America, selling more than 10 products for every child born in the U.S.",
    img:"/assets/images/products/img6.png"
    
    
    
    },
    {
    id:7,
    title:"Babyoye Cotton Full Sleeves Pullover Sweater ",
    price:"701.00",
    desc:"6 to 9 Months, warm and comfortable front zip placket sweater for boys",
    img:"/assets/images/products/img7.png"
    
    
    
    },
    {
    id:8,
    title:"Babyhug Full Sleeves Woollen Dress Polka Dot Print",
    price:"769.00",
    desc:"9 to 12 Months, Stylish round neck dress with shoulder buttons for girls",
    img:"/assets/images/products/img8.png"
    },
    {
    id:9,
    title:"Ollington St. Flutter Sleeves Top & Culottes Floral Print ",
    price:"710.00",
    desc:"Ollington St. is a fashion sets and suits brand that offers top and bottom as a set for kids between 2-10Y. The brand erases the need for parents to make clothing combinations for their kids.",
    img:"/assets/images/products/img9.png"
    }//,
    // {
    // id:10,
    // title:"My NewBorn Baby Boy's and Baby Girl's 3 in 1 Fleece Blanket/Safety Sleeping Bag (White and Pink) - Pack of 2 Pcs ",
    // price:"1,950.00",
    // desc:"Pack of 2 Pc. Very Soft and Attractive Baby Blanket cum Wrapper by MY NEWBORN ",
    // img :"/assets/images/products/img10.png"
    // },
    // {
    // id:11,
    // title:"Johnson's baby Skin Care Wipes, 20 pcs ",
    // price:"79.00",
    // desc:"Johnson's baby wipes with lid protects newborn delicate skin from redness and rashes. These wipes have sponge-like fibres with 3x moisturizing lotion for soft and gentle care for a newborn. Alcohol-free, soap-free. Every Johnson’s product passes a 5 level safety assurance process. No harmful chemicals. Only 100% gentle care. Fliptop on the pack helps keep moisture locked in for longer use. It is clinically mildness proven. ",
    // img :"/assets/images/products/img11.png"
    // },
    // {
    // id:12,
    // title:"StarAndDaisy Comfort 4 in 1 High Chair – Booster Seat in Graffiti Prints (Blue)",
    // price:"3499.00",
    // desc:"4IN1 HIGH CHAIR : Cushion High Chair, Normal Chair, Booster Seat & Chair with wheels.",
    // img :"/assets/images/products/img12.png"
    // },
    // {
    // id:13,
    // title:"99% Pure Water Unscented Baby Wipes(10 pcs x 2) with Medical Grade Fabric for Sensitive Skin ",
    // price:"180.00",
    // desc:"Mother Sparsh 99% Unscented Pure Water Baby Wipes for your baby’s day to day needs! On the go, all the sudden need to change the diaper? Or have to clean up your baby’s hands and mouth after a messy yet yummy treat? No worries, Mother Sparsh wet wipes are here at your rescue! Our 99% Pure Water Baby Wipes are gentle, velvety soft, organic, making them safe to use for cleaning up your baby’s skin from head to toe. Made out of Plant-derived Medical Grade fabric, which is As Good As Cotton Water, helps in preventing rashes.",
    // img :"/assets/images/products/img13.png"
    // },
    // {
    // id:14,
    // title:"Sebamed Baby Body-Milk 400ml",
    // price:"1,234.00",
    // desc:"Baby Sebamed Body – Milk lotion is formulated by Dermatologists for your baby's delicated skin hydration. The natural lipid complex with Sweet Almond Oil and Shea Butter nourishes dry skin.",
    // img :"/assets/images/products/img14.png"
    // },
    // {
    // id:15,
    // title:"R for Rabbit Marshmallow The Smart High Chair - Green ",
    // price:"8,235.00",
    // desc:"Certified for safety: Marshmallow is EN14988 Safety Certified which is one of the most stringent certification defined by European Standards for baby high chairs. Marshmallow is tested for mechanical strength and quality of colour & parts used.",
    // img :"/assets/images/products/img15.png"
    // },
    // {
    // id:16,
    // title:"Trumom USA Electric Steam Sterilizer for Baby Feeding Bottles and Food Steamer 2009 ",
    // price:"2,499.00",
    // desc:"Trumom electric sterilizer for feeding bottles and food steamer. Warranty subject to terms and conditions as on our website and available in select modes of trumom products only. ",
    // img :"/assets/images/products/img16.png"
    // },
    // {
    // id:17,
    // title:"Chicco Baby Moments Gentle Body Wash And Shampoo For Soft Skin And Hair, Dermatologically Tested, Paraben Free (500ml) ",
    // price:"719.00",
    // desc:"Gentle Body Wash and Shampoo formulated to gently cleanse baby€™s delicate hair and skin ",
    // img :"/assets/images/products/img17.png"
    // },
    // {
    // id:18,
    // title:"Safe-O-Kid – Mouth Safety – Very Soft Baby Gums and Early Teething Relaxing Finger Brush And Tongue Cleaner",
    // price:"149.00",
    // desc:"Made of premium silicone, safe for use in babies’ mouths. This baby finger toothbrush 100% food-grade silicone, BPA free. The soft and flexible material leaves your child’s mouth free from the block when you used them.",
    // img :"/assets/images/products/img18.png"
    // },
    // {
    // id:19,
    // title:"Opens in a new window Johnson's baby Care Collection With Organic Cotton Bib -5 gift Items",
    // price:"500.00",
    // desc:"JOHNSON'S baby care collection is an exclusive gifting collection carefully selected to help a new mother celebrate her journey of nurturing a happy, healthy baby. It embodies ...",
    // img :"/assets/images/products/img19.png"
    // },
    // {
    // id:20,
    // title:"Mamaearth Complete Baby Care Kit",
    // price:"2,500.00",
    // desc:"Hi I am your complete solution to taking care of your baby from top to toe and even mosquitoes. Buy me as a combo for your baby or gift this amazing combo of certified toxin ...",
    // img :"/assets/images/products/img20.png"
    // },
    // {
    // id:21,
    // title:"Life Changing Products 18pcs Newborn Baby Gifts Clothing Set",
    // price:"5,000.00",
    // desc:"The Newborn Baby Gifts has 18 pieces of complete clothes a baby will need. The set includes tops, pants, hats, mittens, socks, towels, a jacket, and bibs. All made of twill cotton fabric material which is safe and comfortable for babies. Available in colors of blue, pink, and yellow.",
    // img :"/assets/images/products/img21.png"
    // }
    
    
    ]
    export default Data;