// import React from 'react'
// import { useParams } from 'react-router'
// import { useState } from 'react';
// import DATA from '../Data';
// import { useDispatch } from 'react-redux';
// import {addItem, delItem} from '../redux/actions/index'

// const ProductDetail = () => {
// const [cartBtn, setCartBtn] = useState("Add to Cart")
// {/* Now we need a product id which is pass from the product page. */}
// const proid = useParams();
// const proDetail = DATA.filter(x=>x.id == proid.id)
// const product = proDetail[0];
// console.log(product);

// // We need to store useDispatch in a variable
// const dispatch = useDispatch()

// const handleCart = (product) => {
// if (cartBtn === "Add to Cart") {
// dispatch(addItem(product))
// setCartBtn("Remove from Cart")
// }
// else{
// dispatch(delItem(product))
// setCartBtn("Add to Cart")
// }
// }

// return (
// <>
// <div className="container my-5 py-3">
// <div className="row">
// <div className="col-md-6 d-flex justify-content-center mx-auto product">
// <img src={product.img} alt={product.title}height="400px" />
// </div>
// <div className="col-md-6 d-flex flex-column justify-content-center">
// <h1 className="display-5 fw-bold">{product.title}</h1>
// <hr />
// <h2 className="my-4">₹{product.price}</h2>
// <p className="lead">{product.desc}</p>
// <button onClick={()=>handleCart(product)} className="btn btn-outline-primary my-5">{cartBtn}</button>
// </div>
// </div>
// </div>
// </>
// )
// }

// export default ProductDetail;
// import React, { Component } from 'react';
// import axios from 'axios';
// import { useDispatch } from 'react-redux';
// import {addItem, delItem} from '../redux/actions/index'
// import { useParams } from 'react-router'
// import { useState } from 'react';
// class ProductDetail extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             prod:[],
//             error:' '
//           }
//     }
//     dispatch = useDispatch()
//     handleCart = (prod) => {
//         if (cartBtn === "Add to Cart") {
//         dispatch(addItem(prod))
//         setCartBtn("Remove from Cart")
//         }
//         else{
//         dispatch(delItem(prod))
//         setCartBtn("Add to Cart")
//         }
//         }
//     componentDidMount(){
//         axios.get('http://localhost:8080/getpro/{id}').
//         then(res=>{
//             console.log(res.data);
//             this.setState({
//                 prod:res.data,
//             })
//             console.log(res);
//         }).
//         catch(error=>{
//             //console.log(error);
//           this.setState({
//               errors:'Unable to fetch the information'
//           })
//         })
          
//       }


//     render() { 
//         const{prod,error}=this.state;
//         return ( 
//              <>
// <div className="container my-5 py-3">
// {prod.length?prod.map(prod=>(
// <div className="row">

// <div className="col-md-6 d-flex justify-content-center mx-auto product">
   
    
// <img src={prod.img} alt={prod.title}height="400px" />
// </div>
// <div className="col-md-6 d-flex flex-column justify-content-center">
// <h1 className="display-5 fw-bold">{prod.title}</h1>
// <hr />
// <h2 className="my-4">₹{prod.price}</h2>
// <p className="lead">{prod.desc}</p>
// <button onClick={()=>handleCart(prod)} className="btn btn-outline-primary my-5">{cartBtn}</button> 
// </div>
// </div>)):null}
// </div>
// </>
//          );
//     }
// }
 
// export default ProductDetail;

import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { selectedProduct} from "../redux/actions/productActions"
const ProductDetail= () =>{

    const product=useSelector((state)=>state.product);
    const{img,title,price,descp}=product;
    const{ productId } = useParams();
    const dispatch = useDispatch();
    console.log(product);

    const fetchProductDetail = async ()=>{
        const res= await axios.get(`http://localhost:8080/getpro/${productId}`).catch(err =>{
            console.log("Err",err);
        });
        dispatch(selectedProduct(res.data));
    };
    useEffect(()=>{
    if(productId && productId !=="") fetchProductDetail();
    },[productId]);
    return(
        <div className="container my-5 py-3">
         <div className="row">
         <div className="col-md-6 d-flex justify-content-center mx-auto product">
         <img src={img} alt={title}height="400px" />
        </div>
        <div className="col-md-6 d-flex flex-column justify-content-center">
        <h1 className="display-5 fw-bold">{title}</h1>
        <hr />
        <h2 className="my-4">₹{price}</h2>
         <p className="lead">{descp}</p>
         <button  className="btn btn-outline-primary my-5">Add to cart</button>
        </div>
        </div>
        </div>
    )
}
export default ProductDetail;