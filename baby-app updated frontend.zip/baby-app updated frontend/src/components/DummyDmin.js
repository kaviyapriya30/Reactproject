import React, { Component } from 'react';
import axios from 'axios';
class Admin extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            img:'',
            title:'',
            price:''
         }
    }
    handleChange=event=>{
        this.setState({[event.target.name]:event.target.value})
    }
    handleSubmit= event=>{
        event.preventDefault()
        console.log(this.state)
        axios.post('http://localhost:8080/savepro',this.state).then(res=>{
            console.log(res.data)
        }).catch()
    }
    
    
    render() { 
        const{img,title,price} =this.state;
            return ( <div>
                   <form onSubmit={this.handleSubmit}>
                    <div>
                    <label htmlFor="prodimg">Product img</label>
                    <input type="file" name="img" id="prodimg" value={img} onChange={this.handleChange}></input>
                    </div>
                    <div>
                    <label htmlFor="prodtitle">Productname</label>
                    <input type="text" name="title" id="prodtitle" value={title} onChange={this.handleChange}></input>
                    </div>
                    <div>
                    <label htmlFor="prodprice">Productprice</label>
                    <input type="text" name="price" id="prodprice" value={price} onChange={this.handleChange}></input>
                    </div>
                    <input type="submit" value="Add Product"></input>
                    <input type="reset" value="clear"></input>
                </form>
    
    
            </div> 

        

     );
    }
}
 
export default Admin ;