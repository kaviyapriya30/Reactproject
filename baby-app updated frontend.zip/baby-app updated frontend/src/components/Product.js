
// import React from 'react';
// import { NavLink } from 'react-router-dom';
// import DATA from '../Data';


// const Product1 = () => {const cardItem = (item) => {
// return (
// <div class="card my-5 py-4" key={item.id} style={{width: "30rem"}}>
// <img src= {item.img} class="card-img-top" alt={item.title}/>
// <div class="card-body text-center">
// <h5 class="card-title">{item.title}</h5>
// <p className="lead">Rs{item.price}</p>
// <NavLink to={'/products/Rs{item.id}'} class="btn btn-outline-primary">Buy Now</NavLink>
// </div>
// </div>
// );
// }
// return (
// <div>
// <div className="conatiner py-5">
// <div className="row justify-content-around">
// <div className="col-12 text-center">
// <h1>Product</h1>
// <hr />
// </div></div></div>
// <div className="conatiner">
// <div className="row justify-content-around">
// {DATA.map(cardItem)}
// </div>
// </div>
// </div>
// )
// }
// export default Product1;

// import React, { Component } from 'react';
// import { NavLink } from 'react-router-dom';
// import axios from 'axios';
// class Product1 extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { 
//             prod:[],
//             error:' '

//          }
//     }
//     componentDidMount(){
//         axios.get('http://localhost:8080/getpro').
//         then(res=>{
//             console.log(res.data);
//             this.setState({
//                 prod:res.data,
//             })
//             console.log(res);
//         }).
//         catch(error=>{
//             //console.log(error);
//           this.setState({
//               errors:'Unable to fetch the information'
//           })
//         })
          
//       }
//     render() { 
//         const{prod,errors}=this.state;
//         const Product=()=>{const cardItem=(prod)=>{
//         return(<div>
//              {prod.length ? prod.map(prod=>(
                 
                     
//                 <div className="card my-5 py-4" key={prod.id} style={{width: "30rem"}}>
//                  <img src= {prod.img} className="card-img-top" alt={prod.title}/>
//                 <div className="card-body text-center">
//                <h5 className="card-title">{prod.title}</h5>
//                <p className="lead">Rs{prod.price}</p>
//                <NavLink to={'/products/Rs{item.id}'} className="btn btn-outline-primary">Buy Now</NavLink>
              
//               </div>
              
//               </div>)):null}
//               </div> 
//         )}
//         return (
// <div>
// <div className="conatiner py-5">
// <div className="row justify-content-around">
// <div className="col-12 text-center">
// <h1>Product</h1>
// <hr />
// </div></div></div>
// <div className="conatiner">
// <div className="row justify-content-around">
// {prod.map(prod=>(
//     <div className="card my-5 py-4" key={prod.id} style={{width: "30rem"}}>
//     <img src= {prod.img} className="card-img-top" alt={prod.title}/>
//    <div className="card-body text-center">
//   <h5 className="card-title">{prod.title}</h5>
//   <p className="lead">Rs{prod.price}</p>
//   <NavLink to={'/products/${item.id}'} className="btn btn-outline-primary">Buy Now</NavLink>
 
//  </div>
 
//  </div>)
// )}
// </div>
// </div>
// </div>
// )}

       
        
//      return(
//          <div>
//              <Product></Product>
//          </div>
//      )     
          
          
// }
   

// }
   
// export default Product1;


import React,{useEffect} from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import ProductComponent from "./ProductComponent";
import {setProducts} from '../redux/actions/productActions';
const Product = ()=>{
    const products=useSelector((state)=>state);
    const dispatch=useDispatch();

    const fetchProducts=async()=>{
        const res = await axios.get('http://localhost:8080/getpro').catch((err)=>{
            console.log("Err",err);
        });
        dispatch(setProducts(res.data));
    }
    useEffect(()=>{
        fetchProducts();
    },[]);

    console.log("Products:",products)
    return(
        <div className="ui grid container">
        <ProductComponent></ProductComponent>
        </div>
    )
}
export default Product;