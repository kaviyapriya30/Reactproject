import React, { Component } from 'react';
import axios from 'axios';
class Retrive extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            prod:[],
            error:' '
         }
    }
    componentDidMount(){
        axios.get('http://localhost:8080/getpro').
        then(res=>{
            console.log(res.data);
            this.setState({
                prod:res.data,
            })
            console.log(res);
        }).
        catch(error=>{
            //console.log(error);
          this.setState({
              errors:'Unable to fetch the information'
          })
        })
          
      }
    render() { 
        const{prod,errors}=this.state;
        return ( <div>
              <p>Products</p>
                
                <table>
                    <thead>
                        <tr>
                            <th>Productname</th>
                            <th>Productprice</th>
                            <th>Productdesc</th>
                        </tr>
                    </thead>
                    <tbody>
                    { prod.length ? prod.map(prod=>(
                    <tr key={prod.id}>
                   <td> <img src={prod.img} width="200px" height="300px"></img></td>
                   <td>  {prod.title}  </td>
                     <td>{prod.price}</td>
                    </tr> )):null}</tbody></table>
                   {errors ? <h2>{errors}</h2>:null} 
                 
              
            
        </div> );
    }
}
 
export default Retrive;