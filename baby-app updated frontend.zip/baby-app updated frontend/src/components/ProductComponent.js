import React from "react";
import { useSelector } from "react-redux";
import {Link} from "react-router-dom";


const ProductComponent = ()=>{
    const products=useSelector((state)=>state.allProducts.products);
   
    const renderList=products.map((product)=>{
        const{id,title,img,price} = product;

        return(  
  
    
    <div class="card my-5 py-4" key={id} style={{width: "25rem"}}>
        
     <img src= {img} class="card-img-top" alt={title}/>
    <div class="card-body text-center">
    <h5 class="card-title">{title}</h5>
    <p className="lead">Rs{price}</p>
    < Link to={`/product/${id}`} class="btn btn-outline-primary">Buy Now</Link>
     </div>
    
    
    
     </div>
)});
    return(
        
    <div>
      <div className="conatiner py-5">
      <div className="row justify-content-around">
       <div className="col-12 text-center">
      <h1>Product</h1>
     <hr />
     </div></div></div>
      <div className="conatiner">
     <div className="row justify-content-around">
      {renderList}
     </div>
     </div>
    </div>
     
    )
};
export default ProductComponent;