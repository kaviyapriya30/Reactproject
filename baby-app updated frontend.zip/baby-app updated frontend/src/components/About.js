import React from 'react'
import { NavLink } from 'react-router-dom'
const About1 =() => {
return(
<div>
<div className="container py-5 my-5">
<div className="row">
<div className="col-md-6">
<h1 className="text-primary fw-bold mb-4 ">About Us</h1>
<p className="lead mb-4">
The Baby Clothing tasteful is ”Casual Luxe” and our sole point is to plan top-notch, well-made garments for kids,
with incredible tender loving care, texture, trim, and the requirements of our little clients. We want to be one of the
brands that fill that hole of giving universal quality youngsters garments in the US.Today, Founder and Creative Director
Peter Kenth guarantees the accumulations are always advancing while at the same time remaining consistent with her rule
esteems: quality, development, comfort; utilizing just the best textures.Her plans have an exceptional taste that mixes
form and capacity to make looks that have an all-inclusive intrigue and garments that are ultra-agreeable and amusing to
wear for your little ones.We are extremely eager to dispatch DRESSED UP BY Baby Clothing our legacy enlivened searches
for weddings, festivities, and exceptional events, highlighting hand subtleties, sumptuous textures, and finely created
architect contacts.
</p>
<NavLink to="/contact" className="btn btn-outline-primary px-3">Contact Us</NavLink>
</div>
<div className="col-md-6 d-flex justify-content-center">
<img src="/assets/images/about.png" alt="About Us" height="400px" width="700px"/>
</div>
</div>
</div>



</div>
)
}
export default About1
