
import './App.css';
import Login1 from './components/buttons/Login';


import Footer from './components/Footer';
import Header1 from './components/Header';



function App() {
  return (
    <>
    <Header1></Header1>
    {/* <Admin></Admin>  */}
    {/* <Retrive></Retrive>  */}
      <Footer/>
    
    </>
  );
}

export default App;
