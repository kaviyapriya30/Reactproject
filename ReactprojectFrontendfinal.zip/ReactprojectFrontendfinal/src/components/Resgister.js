import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

class Register extends Component {
    constructor(props) {
        super(props);
        this.state = { 
          name:'',
          email:'',
          password:'',
          mobileno:0
       }
       
    }
    
    handelChange=event=>{
      this.setState({[event.target.name]:event.target.value})

      
  }
  handelSubmit=event=>{
      event.preventDefault()
      console.log(this.state);
      axios.post('http://localhost:8081/signup',this.state).then(res=>{
          console.log(res.data)
          window.location.replace("/products")
          localStorage.setItem("email", JSON. stringify(this.state.email));
         
         
        
         
      }).catch(
          err=>{
              console.log("data already present")
          }
      )
  }

render() { 
      const{name,email,password,mobileno}=this.state;
      
        return (
<section className="vh-100 bg-image" Style="background-image: url('https://wallpapercave.com/wp/wp2982160.jpg');">
  <div className="mask d-flex align-items-center h-100 gradient-custom-3">
    <div className="container h-100">
      <div className="row d-flex justify-content-center align-items-center h-100">
        <div className="col-12 col-md-8 col-lg-6 col-xl-6">
          <div className="card" Style="border-radius: 15px;">
            <div className="card-body p-4" Style="background-color:pink">
              <h2 className="text-uppercase text-center mb-5">Create an account</h2>

              <form onSubmit={this.handelSubmit}>

            <div className="form-outline mb-4">
                <label  htmlfor="form3Example1cg" className="form-label">Your Name</label>
                  <input type="text" id="form3Example1cg" className="form-control form-control-lg" name="name" value={name} onChange={this.handelChange} />
                 
                </div>

                <div className="form-outline mb-4">
                <label htmlfor="form3Example3cg" className="form-label" >Your Email</label>
                  <input type="email" id="form3Example3cg" className="form-control form-control-lg"  name="email" value={email} aria-describedby="emailHelp" onChange={this.handelChange} />
                 
                </div>

                <div className="form-outline mb-4">
                <label htmlfor="form3Example4cg" className="form-label" >Password</label>
                  <input type="password" id="form3Example4cg" className="form-control form-control-lg"  name="password" value={password} onChange={this.handelChange} />
                  
                </div>

                <div className="form-outline mb-4">
                <label  htmlfor="form3Example4cdg" className="form-label" >Mobile number</label>
                  <input type="text" id="form3Example4cdg" className="form-control form-control-lg"  name="mobileno" value={mobileno} onChange={this.handelChange} />
                 
                </div>

                {/* <div className="form-check d-flex justify-content-center mb-5">
                  <input
                    className="form-check-input me-2"
                    type="checkbox"
                    value=""
                    id="form2Example3cg"
                  />
                  <label className="form-check-label" for="form2Example3g">
                    I agree all statements in <a href="#!" className="text-body"><u>Terms of service</u></a>
                  </label>
                </div> */}

                <div className="d-flex justify-content-center">
                <button type="submit" className="btn btn-outline-dark w-100 mt-5">Register</button>
                </div>

                <p className="text-center text-muted mt-5 mb-0">Have already an account? <Link to='/login'> Login Here!!</Link> <u></u></p>

              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
          );
    }
}
 
export default Register;