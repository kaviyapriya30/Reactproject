import React, {useState, useEffect} from 'react';
import { useDispatch } from 'react-redux';
import { addCart } from '../redux/actions';
import { useParams } from 'react-router';
import { NavLink } from 'react-router-dom';
import Skeleton from 'react-loading-skeleton';
import { useSelector } from 'react-redux'
import axios from 'axios';


const Orderhistory = () => {

    const id=localStorage.getItem('productid');
    const {email} = useParams();
    const [product, setProduct] = useState([]);
    const [loading, setLoading] = useState(false);
//    const state = useSelector((state)=> state.handleCart)
   

    

    useEffect(() => {
        const getProduct = async () => {
            setLoading(true);
            
            const response = await fetch(`http://localhost:8081/orders/${email}`);
            setProduct(await response.json());
            console.log(product)
            setLoading(false);
        }
        getProduct();
    }, []);

    const Loading = () => {
        return(
            <>
                <div className="col-md-6">
                    <Skeleton height={400}/>
                </div>
                <div className="col-md-6" style={{lineHeight:2}}>
                    <Skeleton height={50} width={300} />
                    <Skeleton height={75} />
                    <Skeleton height={25} width={150} />
                    <Skeleton height={50} />
                    <Skeleton height={150} />
                    <Skeleton height={50} width={100} />
                    <Skeleton height={50} width={100} style={{marginLeft:6}} />
                </div>
            </>
        )
    }
    const ShowProduct = () => {
        // const id=localStorage.getItem('productid');
        return(
            <>
            <h1 className='text-center '>Order History</h1>
    
            {product.length?product.map(prod=>(
            //     <div className="row no-gutters" key={prod.pid}>
            //     <div className="col-sm-2">
            //         <img className="card-img" src={prod.img} alt={prod.title}></img>
            //     </div>
            //     <br></br>
            //     <div className="col-sm-6">
            //         <div className="card-body">
                    
            //             <h5 className="card-title">Title : {prod.title}</h5>
            //             <p className="card-text">Price : {prod.price*prod.quantity} </p>
            //             <p className="card-text">Quantity : {prod.quantity}</p>
                        
                    
            //        <NavLink to={`/products/${prod.pid}`}><button className="btn btn-dark">Order again</button></NavLink> 

                       
            //             {/* {err? <h2>{err}</h2>:null} 
            //             {result ? <h2>{result}</h2>:null}  */}

                    
            //         </div>
            //     </div>
            // </div>
            
 <div className="px-4 my-5  rounded-3 py-2">
     
<div className="container py-2">
<div className="row justify-content-center">
<div className="col-md-4">
<img src={prod.img} alt={prod.title} height="200px" width="200px" />
</div>
<div className="col-md-4">
<h3>Title: {prod.title}</h3>
<p className="lead fw-bold">
<p className="card-text">Price : {prod.price} </p>
 <p className="card-text">Quantity : {prod.quantity}</p>
    TotalPrice: Rs.{prod.quantity * prod.price}<br></br>
    Ordered Date:{prod.createdDate.split('T')[0]}

</p>
<NavLink to={`/products/${prod.pid}`}><button className="btn btn-dark">Order again</button></NavLink> 
</div>
</div>
</div>
</div>
    
                
                )):null}

    
                
            </>
        )
    }

    return (
        <div>
            <div className="container py-5">
                <div className="row py-4">
                    {loading ? <Loading/> : <ShowProduct/>}
                </div>
            </div>
        </div>
    );
}

export default Orderhistory;
