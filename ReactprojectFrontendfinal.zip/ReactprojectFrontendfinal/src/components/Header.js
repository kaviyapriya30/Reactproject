import React from 'react'
import { Nav,NavDropdown } from 'react-bootstrap'
import { NavLink, Link } from 'react-router-dom'
import CartBtn from './buttons/CartBtn'
import Login1 from './buttons/Login'
import Profile from './buttons/Profile'


import Signup1 from './buttons/Signup'
import Login from './Login'
import Logout from './Logout'
import Orderhistory from './Orderhistory'



const Header = () => {
const user = localStorage.getItem('email');
return (
<>
<nav className="navbar navbar-expand-lg navbar-light bg-alert">
<div className="container-fluid py-2">

<button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span className="navbar-toggler-icon"></span>
</button>

<div className="collapse navbar-collapse" id="navbarSupportedContent">
<ul className="navbar-nav me-auto mb-2 mb-lg-0">
<li className="nav-item">
<NavLink className="nav-link" aria-current="page" to="/">Home</NavLink>
</li>

<li className="nav-item">
<NavLink className="nav-link" to="/about">About</NavLink>
</li>
<li className="nav-item">
<NavLink className="nav-link" to="/contact">Contact</NavLink>
</li>
{/* <li className="nav-item">
<NavLink className="nav-link" to={`/orders/${localStorage.getItem('email')}`}>Orders</NavLink>
</li> */}





</ul >
<NavLink className="navbar-brand mx-auto fw-bold" to="/">Baby-Zone</NavLink>
{/* <Profile></Profile> */}
{localStorage.getItem('email')?
<>

<NavLink className="nav-link text-size:16" Style="color:black"  to="/products">Products</NavLink>
<div className="dropdown">
<button className="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
{user.split('@')[0]}
</button>
<ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
<li>
<Logout></Logout>
</li>
<li>
<Link to={`/orders/${localStorage.getItem('email')}`}>
<button className="btn btn-dark btn-sm ms-2">Myorders</button>
</Link> 
</li>
</ul>

</div>



</>:
<>
<NavLink to="/products" className="nav-link disabled" >Products</NavLink>
<Link
className="btn btn-outline-dark ms-2"
type="button"
to="/Login"
>
Login
</Link>



</>
}


<CartBtn/>
</div>
</div>
</nav>
</>
)
}

export default Header