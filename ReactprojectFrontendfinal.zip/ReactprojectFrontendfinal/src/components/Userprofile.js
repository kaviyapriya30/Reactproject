// import React, {useState, useEffect} from 'react';
// import { useParams } from 'react-router';

// import Skeleton from 'react-loading-skeleton';


// const Userprofile= () => {

//     const {id} = useParams();
//     const [user, setUser] = useState([]);
//     const [loading, setLoading] = useState(false);

   
//     useEffect(() => {
//         const getUser = async () => {
//             setLoading(true);
//             const response = await fetch(`http://localhost:8081/user/${id}`);
//             setUser(await response.json());
//             setLoading(false);
//             localStorage.setItem("u_id",this.state.id);
//         }
//         getUser();
//     }, []);
//     const Loading = () => {
//         return(
//             <>
//                 <div className="col-md-6">
//                     <Skeleton height={400}/>
//                 </div>
//                 <div className="col-md-6" >
//                     <Skeleton height={50} width={300} />
//                     <Skeleton height={75} />
//                     <Skeleton height={25} width={150} />
//                     <Skeleton height={50} />
//                     <Skeleton height={150} />
//                     <Skeleton height={50} width={100} />
//                     <Skeleton height={50} width={100}  />
//                 </div>
//             </>
//         )
//     }
//     const ShowUser = () => {
   
//         return (
//             <div>
       
//             <div className="container py-5 my-5">
//             <div className="row">
//             <div className="col-md-6 d-flex justify-content-center">
//             <div className="col-md-6">
//             <div className="container bcontent">
//         <h2 className="text-light fw-bold mb-4">Products details </h2>
//         <hr />
//         <div className="card" Style="width:800px">
        
//             <div className="row no-gutters" key={user.id}>
//                 <div className="col-md-6">
//                     <img className="card-img" src={user.img} alt="Suresh Dasari Card"></img>
//                 </div>
//                 <div className="col-md-6">
//                     <div className="card-body">
//                         <h3 className='card'>Id : {user.id}</h3>
//                         <h5 className="card-title">Name: {user.name}</h5>
//                         <p className="card-text">mobileno : {user.mobileno} </p>
//                         <p className="card-text">email : {user.email}</p>
//                         {/* <p className="card-text"> : {prod.vendor}</p> */}
//                         {/* <Link to={`/products/${prods.id}`} className="btn btn-primary">Update</Link>| | */}

//                         <a href="#" className="btn btn-primary">Delete</a>
//                     </div>
//                 </div>
//             </div>

//         </div>
//     </div>
//         </div>
         
           

//         </div>  
//         </div>
//         </div>
//         </div>
       
//         );
//     }
//     return (
//         <div>
//             <div className="container py-5">
//                 <div className="row py-4">
//                     {loading ? <Loading/> : <ShowUser/>}
//                 </div>
//             </div>
//         </div>
//     );
// }
 
 
// export default Userprofile;