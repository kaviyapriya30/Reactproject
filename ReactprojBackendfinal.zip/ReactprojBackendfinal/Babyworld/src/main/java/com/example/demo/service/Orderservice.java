package com.example.demo.service;


import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Tuple;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.user.OrderDto;

import com.example.demo.model.Orderdetails;
import com.example.demo.repository.OrderRepository;

@Service
public class Orderservice {

	@Autowired
	OrderRepository order_repo;
	public Orderdetails saveorder(Orderdetails orderdetails) {
		
		return order_repo.save(orderdetails);
	}
//	
//	public Collection<OrderDto> fetchorder(String email) throws Exception
//	{
//		Collection <OrderDto> list=order_repo.findByKeyword(email);
//		
//		if(list.isEmpty()) {
//			throw new Exception("Order is empty");
//		}
//		return list;
//	}
	public List<OrderDto> findByOrder(String email) {
	    List<Tuple> stockTotalTuples = order_repo.findByKeyword(email);
	    
	    List<OrderDto> stockTotalDto = stockTotalTuples.stream()
	            .map(t -> new OrderDto(
	                    t.get(0, String.class), 
	                    t.get(1, Integer.class), 
	                    t.get(2, String.class),
	                    t.get(3,String.class),
	                    t.get(4,Integer.class),
	                    t.get(5,String.class),
	                    t.get(6,Integer.class),
	                    t.get(7,Date.class),
	                    t.get(8,Float.class)
	                    
	                    ))
	            .collect(Collectors.toList());
	    
	    return stockTotalDto;
	}
	
	

}
