package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Adminlogin;
import com.example.demo.model.Productmodel;

import com.example.demo.model.User;
import com.example.demo.service.Adminservice;
import com.example.demo.service.Productservice;
import com.example.demo.service.UserService;

@RestController
@CrossOrigin(origins = {"http://localhost:3001"})
public class AdminController {
	@Autowired
	UserService  userService;
	@Autowired
	Adminservice service;
	@Autowired
	Productservice service1;
	
	@GetMapping(value="/listuser")
	public ResponseEntity<List<User>> saveuser()
	{
		List<User> list=userService.getuser();
		return new ResponseEntity<List<User>>(list,HttpStatus.CREATED);
		
	}
	@PostMapping("/login")
	public Adminlogin loginuser(@RequestBody Adminlogin log) throws Exception
	{
		String tempemail=log.getEmail();
		String temppass=log.getPassword();
		Adminlogin obj=null;
		if(tempemail !=null && temppass!=null) {
			obj=service.fetchuserbyemailandpass(tempemail, temppass);
			
		}
		if(obj ==null)
		{
			throw new Exception("User doesnot exits");
		}
		return obj;
		
	}
	@GetMapping("/getpro/admin")
	public List<Productmodel> getproducts() {
		List <Productmodel> list=service1.getallproducts();
		return list;
	}
	@GetMapping("/getpro/admin/{id}")
	public Productmodel getproductbyid(@PathVariable("id") int id) {
		Productmodel producmodel=service1.getprobyid(id);
		return producmodel;
		
		
	}
	@PostMapping("/updatepro/admin")
	public Productmodel updateproduct(@RequestBody Productmodel product) {
		
		Productmodel pm;
		 pm=service1.updateproduct(product);
		
		return pm;
		
	}
	@GetMapping("/deletepro/admin/{id}")
	public Productmodel deletepro(@PathVariable("id") int id) {
		
		Productmodel productmodel=service1.deletebyid(id);
		return productmodel;
		
	}
		
	

	
}
