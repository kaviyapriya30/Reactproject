package com.example.demo.dto.user;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

//import java.util.Date;


@Data
@AllArgsConstructor

public class OrderDto {
//	int id;
//	String category;
//	String descp;
	String img;
    int pid;
	String descp;
	String title;
	int quantity;
    String vendor;
    int oid;
    Date createdDate;
    float price;
    public OrderDto(String img, int pid, String descp, String title, int quantity, String vendor, int oid,
			Date date,float price) {
		super();
		this.img = img;
		this.pid = pid;
		this.descp = descp;
		this.title = title;
		this.quantity = quantity;
		this.vendor = vendor;
		this.oid = oid;
		this.createdDate = date;
		this.price = price;
		
	}
    public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public OrderDto() {
    	
    }
public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getDescp() {
		return descp;
	}

	public void setDescp(String descp) {
		this.descp = descp;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


//	public OrderDto(Integer integer, String string, String string2) {
//		
//	}
  


}
