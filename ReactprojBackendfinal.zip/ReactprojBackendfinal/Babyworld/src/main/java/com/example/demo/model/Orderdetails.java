package com.example.demo.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;




@Entity
@IdClass(OrderId.class)
public class Orderdetails {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int Oid;
	@Id
	private String email;

	@Id
	private int id;
	
	
	

	
	private Date createdDate=new Date();
	int quantity;
	
	public int getOid() {
		return Oid;
	}

	public void setOid(int oid) {
		Oid = oid;
	}


	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = new Date();
		
	}
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getEmail() {
		return email;
	}

	

	public void setEmail(String email) {
		this.email = email;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public Orderdetails(int oid, String email, int id, Date createdDate, int quantity) {
		super();
		Oid = oid;
		this.email = email;
		this.id = id;
		this.createdDate = new Date();
		this.quantity = quantity;
	}
public Orderdetails() {
	
}
	
	
	
	

}
