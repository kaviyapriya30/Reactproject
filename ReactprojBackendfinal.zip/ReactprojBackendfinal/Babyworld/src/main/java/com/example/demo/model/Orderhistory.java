//package com.example.demo.model;
//
//import javax.persistence.Entity;
//import javax.persistence.NamedNativeQuery;
//import javax.persistence.SqlResultSetMapping;
//
//import com.example.demo.dto.user.OrderDto;
//
//import javax.persistence.ConstructorResult;
//import javax.persistence.ColumnResult;
//
//@Entity
//@NamedNativeQuery(
//	    name = "find_order_dto",
//	    query ="SELECT productmodel.descp, productmodel.title FROM productmodel JOIN orderdetails ON productmodel.id = orderdetails.id where orderdetails.email like :keyword;",
//	    resultSetMapping ="order_dto"
//	)
//@SqlResultSetMapping(
//	    name = "order_dto",
//	    classes = @ConstructorResult(
//	        targetClass = OrderDto.class,
//	        columns = {
//	            @ColumnResult(name = "productmodel.id", type = Integer.class),
//	            @ColumnResult(name = "productmodel.descp", type = String.class),
//	            @ColumnResult(name = "productmodel.title", type = String.class)
//	        }
//	    )
//	)
//
//public class Orderhistory {
//	
//
//}
