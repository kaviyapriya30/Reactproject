package com.example.demo.model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



//@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Productmodel {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String img;
	private String title;
	private String descp;
	private float price;
	private String category;
	private String vendor;
	private String quantity;
	
	@Override
	public String toString() {
		return "Productmodel [id=" + id + ", img=" + img + ", title=" + title + ", descp=" + descp + ", price=" + price
				+ ", category=" + category + ", vendor=" + vendor + ", quantity=" + quantity + "]";
	}
	public Productmodel(int id, String img, String title, String descp, float price, String category, String vendor,
			String quantity) {
		super();
		this.id = id;
		this.img = img;
		this.title = title;
		this.descp = descp;
		this.price = price;
		this.category = category;
		this.vendor = vendor;
		this.quantity = quantity;
	}
	public Productmodel() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescp() {
		return descp;
	}
	public void setDescp(String descp) {
		this.descp = descp;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	
	
}