package com.example.demo.model;

import java.io.Serializable;







public class OrderId implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public OrderId(int oid, String email, int id) {
		super();
		Oid = oid;
		this.email = email;
		this.id =id;
	}
	public OrderId() {
		
	}



	int Oid;
	
	
	String email;
	int id;
	

}
