package com.example.demo.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Register;
import com.example.demo.model.User;
import com.example.demo.repository.Babyrepo;
import com.example.demo.repository.UserRepository;

@Service
public class Babyservice {
	
	@Autowired
	Babyrepo repo;
	@Autowired 
	UserRepository repos;
	

	public Register fetchuserbyemail(String tempemail) {
		
		return  repo.findByEmail(tempemail);
	}

	public Register store(Register register) {
		return repo.save(register);
	}


	public Register fetchuserbyemailandpass(String tempemail, String temppass) {
		return  repo.findByEmailAndPassword(tempemail, temppass);
	}

	public User getcurrentuser(int id) {
	
		return repos.findById(id).get();
		
	}

}
