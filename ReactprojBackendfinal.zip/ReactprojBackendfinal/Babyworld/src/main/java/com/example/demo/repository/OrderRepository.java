package com.example.demo.repository;

import java.util.Collection;
import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.example.demo.model.Orderdetails;

@Repository
public interface OrderRepository extends JpaRepository<Orderdetails, Integer>{
	
	@Query(value="SELECT productmodel.img,productmodel.id, productmodel.descp, productmodel.title, orderdetails.quantity, productmodel.vendor, orderdetails.oid, orderdetails.created_date, productmodel.price FROM productmodel JOIN orderdetails ON productmodel.id = orderdetails.id where orderdetails.email like CONCAT('%', :keyword, '%');", nativeQuery = true)
			 
	List<Tuple> findByKeyword(@Param("keyword") String keyword);

//	   @Query(name = "find_order_dto", nativeQuery = true)
//	   List<OrderDto> findOrderbyProduct(
//	      @Param("keyword") String keyword
//
//	   );

}
