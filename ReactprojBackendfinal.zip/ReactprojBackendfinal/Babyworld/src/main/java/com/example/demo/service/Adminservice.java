package com.example.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Adminlogin;

import com.example.demo.repository.Adminrepository;

@Service
public class Adminservice {
	
	@Autowired
	Adminrepository repos;

	public Adminlogin fetchuserbyemailandpass(String tempemail, String temppass) {
		
		return repos.findByEmailAndPassword(tempemail, temppass);
	}

	

}
