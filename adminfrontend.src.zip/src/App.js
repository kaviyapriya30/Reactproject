
import './App.css';
import Admin from './components/Admin';
import Adminhome from './components/Adminhome';
import Adminlogin from './components/Adminlogin';
import {  Route, Switch } from 'react-router-dom';
import Header from './components/Header';
import Adminproducts from './components/Adminproducts';
import Updateproduct from './components/Updateproduct';
import Admindelete from './components/Admindelete';

function App() {
  return (
    <div>
     
     
    
   
      <Switch>
        <Route exact path="/home" component={Adminhome} />
        <Route exact path="/login" component={Adminlogin} />
        <Route exact path="/users" component={Admin} />
        <Route exact path="/products" component={Adminproducts} />
        <Route exact path="/products/:id" component={Updateproduct} />
        <Route exact path="/delprod/:id" component={Admindelete} />
        
      </Switch> 
    

    </div>
  );
}

export default App;
