import React, { Component } from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
class Adminhome extends Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        return ( <div>
             <div className="container py-5 my-5">
<div className="row">

<div className="col-md-6 d-flex justify-content-center">
<img src="admin.png" alt="About Us" height="400px" width="400px" />
</div>
<div className="col-md-6">
<h1 className="text-light fw-bold mb-4 ">WELCOME ADMIN</h1>
{/* <p className="lead mb-4">
Click here to view Registered users
</p>
<Link to='/users'><button type="button"  className="btn btn-outline-success">Userdetails</button></Link> */}

<table >

<tr>
<td>Click here to view Registered users</td>
<td><Link to='/users'><button type="button"  className="btn btn-outline-success">Userdetails</button></Link></td>
</tr>
<tr>
<td>Click here to view Products</td>
<td><Link to='/products'><button type="button"  className="btn btn-outline-success">Productdetails</button></Link></td>
</tr>
</table>

</div>
</div>
</div>
          
        </div> );
    }
}
 
export default Adminhome;