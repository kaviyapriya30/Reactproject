import React, { Component } from 'react';
import axios from 'axios';
class Admin extends Component { 
    constructor(props) {
        super(props);
        this.state = { 
            user:[],
            errors:''
         }
    }
    state = {  }
    componentDidMount(){
        axios.get('http://localhost:8081/listuser').
        then(res=>{
            console.log(res.data);
            this.setState({
                user:res.data,
            })
            console.log(res);
        }).
        catch(error=>{
            //console.log(error);
          this.setState({
              errors:'Unable to fetch the information'
          })
        })
          
      }
    render() { 
        const{user,errors}=this.state;
        return (
       
        
         <div>
             {/* <h1>User Details
                
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Mobile number</th>
                            <th>Email id</th>
                        </tr>
                    </thead>
                    <tbody>
                    { user.length ? user.map(users=>(
                    <tr key={users.id}>
                   <td> {users.id} </td>
                   <td>  {users.name}  </td>
                     <td>{users.city}</td>
                    
                    
                </tr> )):null} </tbody></table>
                   {errors ? <h2>{errors}</h2>:null} 
                 
                 //stds->entire record is pointed by stds
            </h1>  */}
             {/* <div className="flip-card">
             { user.length ? user.map(users=>(
  <div className="flip-card-inner" key={users.id}>
 
    {/* <div className="flip-card-front">
      <img src="https://cdn.pixabay.com/photo/2017/06/13/12/53/profile-2398782_1280.png" alt="Avatar" Style="width:300px;height:300px;"/>
    </div> */}
    {/* <div className="flip-card-back">
      <h1>Name: {users.name}</h1>
      <p>Mobilenumber: {users.mobileno}</p>
      <p>Emailid: {users.email}</p>
      <hr/>
    </div>
  </div>)):null}
</div>   */}

<link rel="Stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />
<div className="container mt-3 mb-4">
<div className="col-lg-9 mt-4 mt-lg-0">
    <div className="row">
      <div className="col-md-12">
      <h2 className="text-light fw-bold mb-4">User details </h2>
        <hr />
        <div className="user-dashboard-info-box table-responsive mb-0 bg-white p-4 shadow-sm">
        { user.length ? user.map(users=>(
          <table className="table manage-candidates-top mb-0" key={users.id}>
            <thead>
              <tr>
                <th>Name</th>
                <th className="text-center">EmailId</th>
                <th className="action text-right">Mobile number</th>
              </tr>
            </thead>
            <tbody>
              <tr className="candidates-list">
                <td className="title">
                  <div className="thumb">
                    <img className="img-fluid" src="https://media.istockphoto.com/vectors/user-profile-icon-flat-red-round-button-vector-illustration-vector-id1162440985?k=20&m=1162440985&s=170667a&w=0&h=cQJ5HDdUKK_8nNDd_6RBoeDQfILERZnd_EirHTi7acI=" alt="" Style="width:100px;height:100px;"/>
                  </div>
                  <div className="candidate-list-details">
                    <div className="candidate-list-info">
                      <div className="candidate-list-title">
                        <h5 className="mb-0">{users.name}</h5>
                      </div>
                      <div className="candidate-list-option">
                        <ul className="list-unStyled">
                          <li><i className="fas fa-filter pr-1"></i>Kids Cart</li>
                          <li><i className="fas fa-map-marker-alt pr-1"></i></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </td>
                <td className="candidate-list-favourite-time text-center">
                  <a className="candidate-list-favourite order-2">{users.email}</a>
                  {/* <span className="candidate-list-time order-1">Shortlisted</span> */}
                </td>
                <td>
                  <ul className="list-unStyled mb-0 d-flex justify-content-end">
                  <a className="candidate-list-favourite order-2" >{users.mobileno}</a>
                  </ul>
                </td>
              </tr>
             
             
             
            </tbody>
          </table>)):null}
          <div className="text-center mt-3 mt-sm-3">
            <ul className="pagination justify-content-center mb-0">
              <li className="page-item disabled"> <span className="page-link">Prev</span> </li>
              <li className="page-item active" aria-current="page"><span className="page-link">1 </span> <span className="sr-only">(current)</span></li>
              <li className="page-item"><a className="page-link" href="#">2</a></li>
              <li className="page-item"><a className="page-link" href="#">3</a></li>
              <li className="page-item"><a className="page-link" href="#">...</a></li>
              <li className="page-item"><a className="page-link" href="#">25</a></li>
              <li className="page-item"> <a className="page-link" href="#">Next</a> </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

        </div>  
        );
    }
}
 
export default Admin;