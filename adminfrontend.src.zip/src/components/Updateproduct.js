import React, {useState, useEffect} from 'react';

import { useParams } from 'react-router';

import Skeleton from 'react-loading-skeleton';

const Updateproduct = () => {

    const {id} = useParams();
    const [prod, setProduct] = useState([]);
    const [loading, setLoading] = useState(false);

   
    useEffect(() => {
        const getProduct = async () => {
            setLoading(true);
            const response = await fetch(`http://localhost:8081/getpro/admin/${id}`);
            setProduct(await response.json());
            setLoading(false);
        }
        getProduct();
    }, []);

    //  handleinput=(event)=>{

    //     this.setState({[event.target.name]:event.target.value})

    //  }
   

    
    const Loading = () => {
        return(
            <>
                <div className="col-md-6">
                    <Skeleton height={400}/>
                </div>
                <div className="col-md-6" >
                    <Skeleton height={50} width={300} />
                    <Skeleton height={75} />
                    <Skeleton height={25} width={150} />
                    <Skeleton height={50} />
                    <Skeleton height={150} />
                    <Skeleton height={50} width={100} />
                    <Skeleton height={50} width={100}  />
                </div>
            </>
        )
    }
    
 const ShowProduct = () => {
   
        return (
    //         <div>
       
    //         <div className="container py-5 my-5">
    //         <div className="row">
    //         <div className="col-md-6 d-flex justify-content-center">
    //         <div className="col-md-6">
    //         <div className="container bcontent">
    //     <h2 className="text-light fw-bold mb-4">Products details </h2>
    //     <hr />
    //     <div className="card" Style="width:800px">
        
    //         <div className="row no-gutters" key={prod.id}>
    //             <div className="col-md-6">
    //                 <img className="card-img" src={prod.img} alt="Suresh Dasari Card"></img>
    //             </div>
    //             <div className="col-md-6">
    //                 <div className="card-body">
    //                     <h3 className='card'>Id : {prod.id}</h3>
    //                     <h5 className="card-title">Title : {prod.title}</h5>
    //                     <p className="card-text">Price : {prod.price} </p>
    //                     <p className="card-text">Quantity : {prod.quantity}</p>
    //                     <p className="card-text">Vendor : {prod.vendor}</p>
    //                     {/* <Link to={`/products/${prods.id}`} className="btn btn-primary">Update</Link>| | */}

    //                     <a href="#" className="btn btn-primary">Delete</a>
    //                 </div>
    //             </div>
    //         </div>

    //     </div>
    // </div>
    //     </div>
         
           

    //     </div>  
    //     </div>
    //     </div>
    //     </div>

    <div className="row">
        <div className="col-xl-4">
           
            <div className="card mb-4 mb-xl-0">
                <div className="card-header">Profile Picture</div>
                <div className="card-body text-center">
                    
                    <img className="img-account-profile rounded-circle mb-2" src="http://bootdey.com/img/Content/avatar/avatar1.png" alt=""/>
                   
                    <div className="small font-italic text-muted mb-4">JPG or PNG no larger than 5 MB</div>
                    
                    <button className="btn btn-primary" type="button">Upload new image</button>
                </div>
            </div>
        </div>
        <div className="col-xl-8">
           
            <div className="card mb-4">
                <div className="card-header">Product Details</div>
                <div className="card-body">
                    <form>
                        
                        <div class="mb-3">
                            <label className="small mb-1" for="inputUsername">Product name</label>
                            <input className="form-control" id="inputUsername" type="text" name="title" placeholder="Enter your username" value={prod.title}/>
                        </div>
                       
                        <div className="row gx-3 mb-3">
                            
                            <div className="col-md-6">
                                <label  htmlfor="inputFirstName">Price</label>
                                <input className="form-control" id="inputFirstName" type="text" name="price" 
                                placeholder="Enter your first name" value={prod.price}/>
                            </div>
                          
                            <div className="col-md-6">
                                <label className="small mb-1" for="inputLastName">Quantity</label>
                                <input className="form-control" id="inputLastName" type="text" name="quantity" 
                                 placeholder="Enter your last name" value={prod.quantity}/>
                            </div>
                        </div>
                       
                        <div className="row gx-3 mb-3">
                            
                            <div className="col-md-6">
                                <label className="small mb-1" for="inputOrgName">Vendor name</label>
                                <input className="form-control" id="inputOrgName" type="text"name="vendor" 
                                 placeholder="Enter your organization name" value={prod.vendor}/>
                            </div>
                          
                            {/* <div className="col-md-6">
                                <label className="small mb-1" for="inputLocation">Location</label>
                                <input className="form-control" id="inputLocation" type="text" placeholder="Enter your location" value="San Francisco, CA"/>
                            </div> */}
                        </div>
                     
                        <div className="mb-3">
                            <label className="small mb-1" for="inputEmailAddress">Description</label>
                            <input className="form-control" id="inputEmailAddress" type="text" name="descp" 
                            placeholder="Enter your email address" value={prod.descp}/>
                        </div>
                       
                        {/* <div className="row gx-3 mb-3">
                            
                            <div className="col-md-6">
                                <label className="small mb-1" for="inputPhone">Phone number</label>
                                <input className="form-control" id="inputPhone" type="tel" placeholder="Enter your phone number" value="555-123-4567"/>
                            </div>
                            
                            <div className="col-md-6">
                                <label className="small mb-1" for="inputBirthday">Birthday</label>
                                <input className="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="06/10/1988"/>
                            </div>
                        </div> */}
                      
                        <button className="btn btn-primary" type="submit">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>



       
        );
    }
    return (
        <div>
            <div className="container py-5">
                <div classNameName="row py-4">
                    {loading ? <Loading/> : <ShowProduct/>}
                </div>
            </div>
        </div>
    );
}
 
export default Updateproduct;