import React, { Component } from 'react';
class Admindelete extends Component {
    constructor(props) {
        super(props);
    }
    state = {  }


    
    render() { 
        return ( 
        <div>

        </div> );
    }
}
 
export default Admindelete;