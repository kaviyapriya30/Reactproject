import React, { Component } from 'react';
import axios from 'axios';
class Adminlogin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email:'',
            password:'',
            error:''
          }
    }
    state = {  }
    handelChange=event=>{
        this.setState({[event.target.name]:event.target.value})
    }
    handelSubmit=event=>{
  
        
        event.preventDefault()
        console.log(this.state);
        axios.post('http://localhost:8081/login',this.state). then(res=>{
            console.log(res.data);
            window.location.replace("/home")
            
  
        }).catch(
            err=>{
                console.log("data already present")
                this.setState({error:'Access blocked for Invalid Credentials'})
                
            }
        )
      
    }
    render() { 
        const{email,password,error}=this.state
        return (
            <div className="container">
           


<div class="login-box">
  <h2>Admin-Login</h2>
  
  {error ? <h2 className='text-danger'>{error}</h2>:null} 
                    
  <form onSubmit={this.handelSubmit}>
    <div class="user-box">
      <input type="text" name="email" value={email} aria-describedby="emailHelp" onChange={this.handelChange} required=""/>
      <label>Username</label>
    </div>
    <div class="user-box">
      <input type="password" name="password" value={password} onChange={this.handelChange} required=""/>
      <label>Password</label>
    </div>
    < button type="submit">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      Submit
    </button>
  </form>
</div>


   </div> 
    
        );
    }
}
 
export default Adminlogin;

