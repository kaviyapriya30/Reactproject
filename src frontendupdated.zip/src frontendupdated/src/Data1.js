const Data1=[
    {
    id:1,
    img:"/assets/images/offer/img1.png"
    },
    {
    id:2,
    img:"/assets/images/offer/img2.png"
    },
    // {
    // id:3,
    // img:"/assets/images/offer/img3.png"
    // },
    {
    id:4,
    img:"/assets/images/offer/img4.png"
    },
    {
    id:5,
    img:"/assets/images/offer/img5.png"
    },
    {
    id:6,
    img:"/assets/images/offer/img6.png"
    },
    {
    id:7,
    img:"/assets/images/offer/img7.png"
    },
    {
    id:8,
    img:"/assets/images/offer/img8.png"
    },
    {
    id:9,
    img:"/assets/images/offer/img9.png"
    }
    
    
    
    ]
    export default Data1;