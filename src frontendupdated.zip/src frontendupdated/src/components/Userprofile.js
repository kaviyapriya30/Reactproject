import React, { Component } from 'react';
class Userprofile extends Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        return ( <div>

            
        </div> );
    }
}
 
export default Userprofile;