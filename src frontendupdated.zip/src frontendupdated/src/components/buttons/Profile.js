import React from 'react'
import { NavLink } from 'react-router-dom';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import Login1 from './Login';
import Signup1 from './Signup';

const Profile = () => {

return(
    <div class="dropdown">
    <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Profile
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><NavLink className="nav-link" to="/login">Login</NavLink></li>
    <li><NavLink className="nav-link" to="/register">Register</NavLink></li>
    </ul>
    </div>

);

}



export default Profile;