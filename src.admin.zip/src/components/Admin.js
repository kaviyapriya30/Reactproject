import React, { Component } from 'react';
import axios from 'axios';
class Admin extends Component { 
    constructor(props) {
        super(props);
        this.state = { 
            user:[],
            errors:''
         }
    }
    state = {  }
    componentDidMount(){
        axios.get('http://localhost:8081/listuser').
        then(res=>{
            console.log(res.data);
            this.setState({
                user:res.data,
            })
            console.log(res);
        }).
        catch(error=>{
            //console.log(error);
          this.setState({
              errors:'Unable to fetch the information'
          })
        })
          
      }
    render() { 
        const{user,errors}=this.state;
        return (
            <div>
       
            <div className="container py-5 my-5">
            <div className="row">
            <div className="col-md-6 d-flex justify-content-center">
            <div className="col-md-6">
         
            <h1 className="text-light fw-bold mb-4">Userdetails
                
                <table text-align= 'center'>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Mobile number</th>
                            <th>Email id</th>
                        </tr>
                    </thead>
                    <tbody>
                    { user.length ? user.map(users=>(
                    <tr key={users.id}>
                   <td> {users.name} </td>
                   <td>  {users.mobileno}  </td>
                     <td>{users.email}</td>
                    
                    
                </tr> )):null} </tbody></table>
                   {errors ? <h2>{errors}</h2>:null} 
                 
                {/* //stds->entire record is pointed by stds */}
            </h1>

        </div>  
        </div>
        </div>
        </div>
        </div>
        );
    }
}
 
export default Admin;