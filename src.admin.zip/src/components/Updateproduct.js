import React, { Component } from 'react';
class Updateproduct extends Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        return ( <div>
           <div className=''="container rounded bg-white mt-5 mb-5">
           <div className="content-panel">
                    <h2 className="title">Profile<span className="pro-label label label-warning">PRO</span></h2>
                    <form className="form-horizontal">
                        <fieldset className="fieldset">
                            <h3 className="fieldset-title">Personal Info</h3>
                            <div className="form-group avatar">
                                <figure className="figure col-md-2 col-sm-3 col-xs-12">
                                    <img className="img-rounded img-responsive" src="https://bootdey.com/img/Content/avatar/avatar1.png" alt=""/>
                                </figure>
                                <div className="form-inline col-md-10 col-sm-9 col-xs-12">
                                    <input type="file" className="file-uploader pull-left"/>
                                    <button type="submit" className="btn btn-sm btn-default-alt pull-left">Update Image</button>
                                </div>
                            </div>
                            <div className="form-group">
                                <label className="col-md-2 col-sm-3 col-xs-12 control-label">User Name</label>
                                <div className="col-md-10 col-sm-9 col-xs-12">
                                    <input type="text" className="form-control" value="Rebecca"/>
                                </div>
                            </div>
        
                            <div className="form-group">
                                <label className="col-md-2 col-sm-3 col-xs-12 control-label">First Name</label>
                                <div className="col-md-10 col-sm-9 col-xs-12">
                                    <input type="text" className="form-control" value="Rebecca"/>
                                </div>
                            </div>
                            <div className="form-group">
                                <label className="col-md-2 col-sm-3 col-xs-12 control-label">Last Name</label>
                                <div className="col-md-10 col-sm-9 col-xs-12">
                                    <input type="text" className="form-control" value="Sanders"/>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset className="fieldset">
                            <h3 className="fieldset-title">Contact Info</h3>
                            <div className="form-group">
                                <label className="col-md-2  col-sm-3 col-xs-12 control-label">Email</label>
                                <div className="col-md-10 col-sm-9 col-xs-12">
                                    <input type="email" className="form-control" value="Rebecca@website.com"/>
                                    <p className="help-block">This is the email </p>
                                </div>
                            </div>
                            <div className="form-group">
                                <label className="col-md-2  col-sm-3 col-xs-12 control-label">Twitter</label>
                                <div className="col-md-10 col-sm-9 col-xs-12">
                                    <input type="text" className="form-control" value="SpeedyBecky"/>
                                    <p className="help-block">Your twitter username</p>
                                </div>
                            </div>
                            <div className="form-group">
                                <label className="col-md-2  col-sm-3 col-xs-12 control-label">Linkedin</label>
                                <div className="col-md-10 col-sm-9 col-xs-12">
                                    <input type="url" className="form-control" value="https://www.linkedin.com/in/lorem"/>
                                    <p className="help-block">eg. https://www.linkedin.com/in/yourname</p>
                                </div>
                            </div>
                        </fieldset>
                        <hr>
                        <div className="form-group">
                            <div className="col-md-10 col-sm-9 col-xs-12 col-md-push-2 col-sm-push-3 col-xs-push-0">
                                <input className="btn btn-primary" type="submit" value="Update Profile"/>
                            </div>
                        </div>
                    </form>
                </div>
   </div>
</div>

            
 );
    }
}
 
export default Updateproduct;