import React, { Component } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';
class Adminproducts extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            prod:[],
            errors:''
         }
    }
    state = {  }
    componentDidMount(){
        axios.get('http://localhost:8081/getpro/admin').
        then(res=>{
            console.log(res.data);
            this.setState({
                prod:res.data,
            })
            console.log(res);
        }).
        catch(error=>{
            //console.log(error);
          this.setState({
              errors:'Unable to fetch the information'
          })
        })
          
      }
    render() { 
        const{prod,errors}=this.state;
        return (
            <div>
       
            <div className="container py-5 my-5">
            <div className="row">
            <div className="col-md-6 d-flex justify-content-center">
            <div className="col-md-6">
            <div className="container bcontent">
        <h2 className="text-light fw-bold mb-4">Products details </h2>
        <hr />
        <div className="card" Style="width: 800px;">
        { prod.length ? prod.map(prods=>(
            <div className="row no-gutters" key={prods.id}>
                <div className="col-sm-5">
                    <img className="card-img" src={prods.img} alt="Suresh Dasari Card"></img>
                </div>
                <div className="col-sm-7">
                    <div className="card-body">
                        <h3 className='card'>Id : {prods.id}</h3>
                        <h5 className="card-title">Title : {prods.title}</h5>
                        <p className="card-text">Price : {prods.price} </p>
                        <p className="card-text">Quantity : {prods.quantity}</p>
                        <p className="card-text">Vendor : {prods.vendor}</p>
                        <Link to={`/products/${prods.id}`} className="btn btn-primary">Update</Link>| |

                        <a href="#" className="btn btn-primary">Delete</a>
                    </div>
                </div>
            </div>
        )):null} 
        </div>
    </div>
        </div>
         
           

        </div>  
        </div>
        </div>
        </div>
       
        );
    }
}
 
export default Adminproducts;