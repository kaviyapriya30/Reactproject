import React, { Component } from 'react';
import axios from 'axios';
class Adminlogin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email:'',
            password:'',
            error:''
          }
    }
    state = {  }
    handelChange=event=>{
        this.setState({[event.target.name]:event.target.value})
    }
    handelSubmit=event=>{
  
        
        event.preventDefault()
        console.log(this.state);
        axios.post('http://localhost:8081/login',this.state). then(res=>{
            console.log(res.data);
            window.location.replace("/home")
            
  
        }).catch(
            err=>{
                console.log("data already present")
                this.setState({error:'Access blocked for Invalid Credentials'})
                
            }
        )
      
    }
    render() { 
        const{email,password,error}=this.state
        return (
            <div className="container">
            {/* <div className="row">
                <div className="col-lg-3 col-md-2"></div>
                <div className="col-lg-6 col-md-8 login-box">
                    <div className="col-lg-12 login-key">
                        <i className="fa fa-key" aria-hidden="true"></i>
                    </div>

                       {error ? <h2 className='text-danger'>{error}</h2>:null} 
                    <div className="col-lg-12 login-title">
                        ADMIN PANEL
                    </div>
                    
                    <div className="col-lg-12 login-form">
                        <div className="col-lg-12 login-form">
                            <form onSubmit={this.handelSubmit}>
                                <div className="form-group">
                                    <label htmlfor="email" className="form-control-label">USERNAME</label>
                                    <input type="text" className="form-control" id="email" name="email" value={email} aria-describedby="emailHelp" onChange={this.handelChange}></input>
                                </div>
                                <div className="form-group">
                                    <label htmlfor="pass" className="form-control-label">PASSWORD</label>
                                    <input type="password" className="form-control" id="pass" name="password" value={password} onChange={this.handelChange}></input>
                                </div>
  
                                <div className="col-lg-12 loginbttm">
                                    <div className="col-lg-6 login-btm login-text">
                                      
                                    </div>
                                    <div className="col-lg-6 login-btm login-button">
                                        <button type="submit" className="btn btn-outline-primary">LOGIN</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-2"></div>
             </div>
         </div> */}


<div class="login-box">
  <h2>Admin-Login</h2>
  
  {error ? <h2 className='text-danger'>{error}</h2>:null} 
                    
  <form onSubmit={this.handelSubmit}>
    <div class="user-box">
      <input type="text" name="email" value={email} aria-describedby="emailHelp" onChange={this.handelChange} required=""/>
      <label>Username</label>
    </div>
    <div class="user-box">
      <input type="password" name="password" value={password} onChange={this.handelChange} required=""/>
      <label>Password</label>
    </div>
    < button type="submit">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      Submit
    </button>
  </form>
</div>


   </div> 
    
        );
    }
}
 
export default Adminlogin;

